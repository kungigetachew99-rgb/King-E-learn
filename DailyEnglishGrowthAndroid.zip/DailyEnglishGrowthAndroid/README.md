# Daily English Growth — Native Android starter project

This is a native Android app source project written in Kotlin using standard Android views (no third-party UI library).

## Features in this starter
- Five vocabulary words with meanings and examples.
- Daily phrase practice.
- A daily mini lesson that rotates between English, mathematics, electrical engineering, technology, personal development, and revision.
- Writing and lesson-answer fields saved locally.
- Four-task progress bar and daily task checklist.
- Vocabulary quiz.
- Daily 5:00 AM reminder setup and test notification.
- Basic recent progress history and text export.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `DailyEnglishGrowthAndroid` folder in Android Studio.
3. Let Gradle sync and install any SDK components it requests (compile SDK 35).
4. Choose **Build > Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

## Reminder notes
- Tap **Enable 5:00 AM reminder** inside the app and allow notifications.
- Android power management can delay reminders on some devices.
- This starter schedules an inexact follow-up alarm after the first reminder to avoid requesting special exact-alarm access. For production use, review current Android alarm/notification requirements and test on the target phone.

## Development status
This is source code, not a precompiled APK. It has not been compiled or device-tested in this environment. A computer with Android Studio is needed to build the installable APK.
