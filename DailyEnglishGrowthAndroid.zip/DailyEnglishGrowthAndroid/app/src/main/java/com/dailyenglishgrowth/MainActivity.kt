package com.dailyenglishgrowth

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("learning_progress", Context.MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var tasksText: TextView

    private val wordsByDay = listOf(
        listOf(
            Word("Resilient", "Able to recover and keep going after difficulty.", "I want to be resilient when learning something difficult."),
            Word("Consistent", "Doing something regularly.", "Consistent practice helps me improve my English."),
            Word("Curious", "Eager to learn or know something.", "I am curious about how electrical systems work."),
            Word("Progress", "Improvement toward a goal.", "I can see progress when I practise every day."),
            Word("Confident", "Believing in your ability.", "I want to become more confident when speaking English.")
        ),
        listOf(
            Word("Improve", "To make something better.", "I practise speaking to improve my English."),
            Word("Opportunity", "A good chance to do something.", "University gives me an opportunity to learn."),
            Word("Explain", "To make an idea clear.", "Could you explain that in a simpler way?"),
            Word("Achieve", "To succeed in reaching a goal.", "I want to achieve my academic goals."),
            Word("Focus", "To give attention to one thing.", "I focus on learning useful phrases.")
        ),
        listOf(
            Word("Patient", "Able to wait calmly.", "I try to be patient with myself while learning."),
            Word("Effort", "The energy used to do something.", "Small effort every day can make a difference."),
            Word("Challenge", "Something difficult that tests your ability.", "Speaking English is a challenge I can work on."),
            Word("Express", "To communicate a thought or feeling.", "I want to express my ideas clearly."),
            Word("Fluent", "Able to speak a language smoothly.", "I am working toward becoming more fluent.")
        ),
        listOf(
            Word("Reliable", "Able to be trusted.", "A reliable teammate finishes their tasks."),
            Word("Develop", "To grow or make something stronger.", "I want to develop my writing skills."),
            Word("Describe", "To say what something is like.", "Can you describe your daily routine?"),
            Word("Review", "To look at something again to learn it.", "I review new words before sleeping."),
            Word("Goal", "Something you work toward.", "My goal is to speak English with confidence.")
        ),
        listOf(
            Word("Practical", "Useful in real situations.", "I learn practical phrases for university."),
            Word("Communicate", "To share information or ideas.", "Clear words help us communicate."),
            Word("Mistake", "Something that is not correct.", "A mistake can help me learn."),
            Word("Routine", "A regular way of doing things.", "My morning routine includes English practice."),
            Word("Independent", "Able to do things by yourself.", "I am becoming an independent learner.")
        )
    )

    private val phrases = listOf(
        "Could you speak more slowly?",
        "I didn't catch that.",
        "Let me think for a moment.",
        "Could you explain that?",
        "That's a good question."
    )

    private val lessons = listOf(
        Lesson("English: Give a reason with because", "Use because to explain why something happens.", "I practise English because I want to communicate confidently."),
        Lesson("Mathematics: Work step by step", "For a difficult problem, write what is given, choose a formula, substitute values, then check your answer.", "Try: What are the four steps you can use to solve a problem?"),
        Lesson("Electrical engineering: Voltage", "Voltage is the electrical potential difference between two points. It is measured in volts (V).", "A 9 V battery provides a potential difference of 9 volts."),
        Lesson("English: Present simple", "Use the present simple for routines. Add -s or -es with he, she, or it.", "I practise every morning. My friend practises every evening."),
        Lesson("Technology: What is an algorithm?", "An algorithm is a clear sequence of steps used to solve a problem or complete a task.", "A recipe and a computer program can both describe step-by-step procedures."),
        Lesson("Personal development: Small habits", "A small habit is easier to repeat when you connect it to a routine you already have.", "After breakfast, practise five English words for five minutes."),
        Lesson("Weekly revision", "Reviewing helps move learning into long-term memory. Try recalling ideas before looking at the answer.", "Name one word and one idea you learned this week.")
    )

    private fun dateKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun dayIndex(): Int = ((System.currentTimeMillis() / 86_400_000L) % 7).toInt()
    private fun vocabIndex(): Int = ((System.currentTimeMillis() / 86_400_000L) % wordsByDay.size).toInt()
    private fun taskKey(task: String) = "${dateKey()}_$task"
    private fun done(task: String) = prefs.getBoolean(taskKey(task), false)
    private fun setDone(task: String, value: Boolean) { prefs.edit().putBoolean(taskKey(task), value).apply(); updateProgress() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        buildScreen()
        updateProgress()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            setBackgroundColor(0xFFF7F5EF.toInt())
        }
        scroll.addView(content)
        setContentView(scroll)

        pageText("🌱 Daily English Growth", 27, true, 0xFF173B35.toInt())
        pageText(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()), 14, false, 0xFF687771.toInt())
        space(10)
        pageText("Small practice. Stronger English.", 22, true, 0xFF173B35.toInt())
        pageText("Build your English skills while learning about mathematics, electrical engineering, technology, and personal development.", 15, false, 0xFF37443F.toInt())
        space(12)

        card {
            text("TODAY'S PROGRESS", 13, true, 0xFF687771.toInt())
            progressBar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal)
            progressBar.max = 100
            addView(progressBar, LinearLayout.LayoutParams(-1, dp(12)).apply { topMargin = dp(8) })
            progressText = text("0%", 23, true, 0xFF173B35.toInt())
            tasksText = text("0 of 4 tasks complete", 14, false, 0xFF687771.toInt())
        }

        heading("Today's checklist")
        taskCheck("words", "Review five new words", "Read each meaning and example aloud.")
        taskCheck("phrase", "Practise a useful phrase", "Say it out loud and write your own sentence.")
        taskCheck("lesson", "Learn today's new topic", "Read the mini lesson and answer its question.")
        taskCheck("quiz", "Complete a quick quiz", "Test your understanding.")

        heading("Five words for today")
        val words = wordsByDay[vocabIndex()]
        card {
            words.forEachIndexed { i, w ->
                text("${i + 1}. ${w.name}", 18, true, 0xFF173B35.toInt())
                text(w.meaning, 14, false, 0xFF687771.toInt())
                text("Example: “${w.example}”", 14, false, 0xFF37443F.toInt())
                space(7)
            }
        }

        heading("Useful English phrase")
        card {
            text(phrases[vocabIndex() % phrases.size], 20, true, 0xFF173B35.toInt())
            text("Read it aloud three times. Then try using it in a conversation at university.", 14, false, 0xFF687771.toInt())
        }

        heading("Learn something new")
        val lesson = lessons[dayIndex()]
        card {
            text(lesson.title, 19, true, 0xFF173B35.toInt())
            text(lesson.body, 15, false, 0xFF37443F.toInt())
            space(8)
            text("Try it: ${lesson.example}", 14, true, 0xFF8A651C.toInt())
            val answer = EditText(this@MainActivity).apply {
                hint = "Write your answer here"
                minLines = 2
                setText(prefs.getString("${dateKey()}_lesson_answer", ""))
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            addView(answer, LinearLayout.LayoutParams(-1, -2))
            button("Save lesson answer") {
                prefs.edit().putString("${dateKey()}_lesson_answer", answer.text.toString()).apply()
                if (answer.text.toString().isNotBlank()) setDone("lesson", true)
                Toast.makeText(this@MainActivity, "Answer saved on this device.", Toast.LENGTH_SHORT).show()
            }
        }

        heading("Writing practice")
        card {
            text("Write one sentence using a word from today's list.", 15, true, 0xFF173B35.toInt())
            val writing = EditText(this@MainActivity).apply {
                hint = "Today I want to improve..."
                minLines = 3
                setText(prefs.getString("${dateKey()}_writing", ""))
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            addView(writing, LinearLayout.LayoutParams(-1, -2))
            button("Save my writing") {
                prefs.edit().putString("${dateKey()}_writing", writing.text.toString()).apply()
                if (writing.text.toString().isNotBlank()) setDone("phrase", true)
                Toast.makeText(this@MainActivity, "Writing saved on this device.", Toast.LENGTH_SHORT).show()
            }
        }

        heading("Quick quiz")
        card {
            val questions = listOf(
                Triple("What does 'resilient' mean?", listOf("Able to recover after difficulty", "Always in a hurry", "Unable to learn"), 0),
                Triple("Choose the correct sentence.", listOf("I am practise daily.", "I practise daily.", "I practising daily."), 1),
                Triple("Which is a polite request?", listOf("Explain now!", "Could you explain that, please?", "You explain."), 1),
                Triple("What does 'consistent' mean?", listOf("Doing something regularly", "Feeling confused", "Finishing instantly"), 0),
                Triple("Complete: I study English ___ I want to improve.", listOf("because", "although", "yesterday"), 0)
            )
            val q = questions[vocabIndex() % questions.size]
            text(q.first, 17, true, 0xFF173B35.toInt())
            val group = RadioGroup(this@MainActivity).apply { orientation = RadioGroup.VERTICAL }
            q.second.forEachIndexed { i, option ->
                group.addView(RadioButton(this@MainActivity).apply { text = option; id = View.generateViewId(); tag = i })
            }
            addView(group)
            button("Check answer") {
                val selected = group.findViewById<RadioButton>(group.checkedRadioButtonId)
                if (selected == null) Toast.makeText(this@MainActivity, "Choose an answer first.", Toast.LENGTH_SHORT).show()
                else {
                    val correct = (selected.tag as Int) == q.third
                    AlertDialog.Builder(this@MainActivity).setMessage(if (correct) "Correct! Well done." else "Not quite. Correct answer: ${q.second[q.third]}")
                        .setPositiveButton("OK") { _, _ -> setDone("quiz", true) }.show()
                }
            }
        }

        heading("Daily reminder — 5:00 AM")
        card {
            text("Set a daily notification to remind you to practise.", 15, false, 0xFF37443F.toInt())
            button("Enable 5:00 AM reminder") { requestNotificationsAndSchedule() }
            button("Send test notification") { showTestNotification() }
            text("Reminder time is set to 5:00 AM. Android notification permission is required. Battery restrictions on some devices may delay alarms.", 12, false, 0xFF687771.toInt())
        }

        heading("Your practice history")
        card {
            val history = (0..6).mapNotNull { offset ->
                val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }
                val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
                val count = listOf("words", "phrase", "lesson", "quiz").count { prefs.getBoolean("${key}_$it", false) }
                if (count > 0) "${SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(c.time)} — $count/4 tasks" else null
            }
            text(if (history.isEmpty()) "Your completed days will appear here." else history.joinToString("\n"), 14, false, 0xFF37443F.toInt())
            button("Export progress summary") {
                val summary = buildString {
                    appendLine("Daily English Growth progress")
                    for (offset in 0..29) {
                        val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }
                        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
                        val count = listOf("words", "phrase", "lesson", "quiz").count { prefs.getBoolean("${key}_$it", false) }
                        if (count > 0) appendLine("$key: $count/4 tasks")
                    }
                }
                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, summary) }
                startActivity(Intent.createChooser(send, "Export progress"))
            }
        }
        space(20)
        pageText("Patience, consistency, and hard work. 🌿", 14, true, 0xFF173B35.toInt(), Gravity.CENTER)
    }

    private fun taskCheck(key: String, title: String, subtitle: String) {
        card {
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val check = CheckBox(this@MainActivity).apply {
                isChecked = done(key)
                setOnCheckedChangeListener { _, checked -> setDone(key, checked) }
            }
            row.addView(check)
            val texts = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(TextView(this@MainActivity).apply { text = title; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(0xFF172521.toInt()) })
            texts.addView(TextView(this@MainActivity).apply { text = subtitle; textSize = 13f; setTextColor(0xFF687771.toInt()) })
            row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            addView(row)
        }
    }

    private fun updateProgress() {
        if (!::progressBar.isInitialized) return
        val count = listOf("words", "phrase", "lesson", "quiz").count { done(it) }
        progressBar.progress = count * 25
        progressText.text = "${count * 25}%"
        tasksText.text = "$count of 4 tasks complete"
    }

    private fun requestNotificationsAndSchedule() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 900)
        } else scheduleDailyReminder()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 900 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) scheduleDailyReminder()
        else Toast.makeText(this, "Allow notifications in Android settings to receive reminders.", Toast.LENGTH_LONG).show()
    }

    private fun scheduleDailyReminder() {
        createNotificationChannel()
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(this, 501, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 5); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        }
        Toast.makeText(this, "Daily 5:00 AM reminder enabled.", Toast.LENGTH_LONG).show()
    }

    private fun showTestNotification() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestNotificationsAndSchedule()
            return
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, "daily_english")
            else android.app.Notification.Builder(this)
        notification.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Daily English Growth")
            .setContentText("Time for five new words and your daily learning session!")
            .setAutoCancel(true)
        nm.notify(1001, notification.build())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("daily_english", "Daily learning reminders", NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "Daily 5 AM English and learning reminder"
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun heading(value: String) {
        space(13)
        pageText(value, 21, true, 0xFF173B35.toInt())
        space(5)
    }

    private fun card(block: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
        content.addView(box, params)
        box.block()
    }

    private fun pageText(value: String, size: Int, bold: Boolean, color: Int, gravity: Int = Gravity.START): TextView {
        val view = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            this.gravity = gravity
            setPadding(0, dp(2), 0, dp(3))
        }
        content.addView(view)
        return view
    }

    private fun LinearLayout.text(value: String, size: Int, bold: Boolean, color: Int): TextView {
        val view = TextView(this@MainActivity).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(3))
        }
        addView(view)
        return view
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; setOnClickListener { action() } }
        addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
    }

    private fun LinearLayout.button(label: String, action: () -> Unit) {
        val b = Button(this@MainActivity).apply { text = label; setOnClickListener { action() } }
        addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
    }

    private fun space(dpValue: Int) {
        content.addView(Space(this), LinearLayout.LayoutParams(1, dp(dpValue)))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

data class Word(val name: String, val meaning: String, val example: String)
data class Lesson(val title: String, val body: String, val example: String)
